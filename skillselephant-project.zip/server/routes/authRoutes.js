const express = require("express");

const {
  registerUser,
  createTeacher,
  setupFirstAdmin,
  loginUser,
  getCurrentUser,
  updateProfile,
  changePassword,
  getPendingUsers,
  approveUser,
  rejectUser,
  getAllUsers,
  getStudents,
  getTeachers,
  uploadProfilePhoto,
removeProfilePhoto,
} = require("../controllers/authController");
const {
  forgotPassword,
  verifyResetOTP,
  resetPassword,
} = require("../controllers/passwordResetController");
const {
  protect,
  authorizeRoles,
} = require("../middleware/authMiddleware");

const {
  uploadProfilePhoto: uploadProfilePhotoMiddleware,
} = require("../middleware/uploadMiddleware");

const router = express.Router();

/* =====================================================
   PUBLIC AUTH ROUTES
===================================================== */

// REGISTER
router.post("/register", registerUser);
router.post("/admin-setup", setupFirstAdmin);
// LOGIN
router.post("/login", loginUser);
// Forgot Password Routes
router.post("/forgot-password", forgotPassword);
router.post("/verify-reset-otp", verifyResetOTP);
router.post("/reset-password", resetPassword);
/* =====================================================
   AUTHENTICATED USER ROUTES
===================================================== */

// CURRENT USER
router.get(
  "/me",
  protect,
  getCurrentUser
);

// UPDATE PROFILE
router.put(
  "/update-profile",
  protect,
  updateProfile
);
/* =====================================================
   PROFILE PHOTO
===================================================== */

router.post(
  "/profile-photo",
  protect,
  uploadProfilePhotoMiddleware,
  uploadProfilePhoto
);

router.delete(
  "/profile-photo",
  protect,
  removeProfilePhoto
);

// CHANGE PASSWORD
router.put(
  "/change-password",
  protect,
  changePassword
);

/* =====================================================
   ADMIN - USER MANAGEMENT
===================================================== */

// GET ALL PENDING REGISTRATION REQUESTS
router.get(
  "/pending-users",
  protect,
  authorizeRoles("ADMIN"),
  getPendingUsers
);

// APPROVE USER
router.put(
  "/approve-user/:id",
  protect,
  authorizeRoles("ADMIN"),
  approveUser
);

// REJECT USER
router.put(
  "/reject-user/:id",
  protect,
  authorizeRoles("ADMIN"),
  rejectUser
);

// GET ALL STUDENTS AND TEACHERS
router.get(
  "/users",
  protect,
  authorizeRoles("ADMIN"),
  getAllUsers
);

// GET ALL STUDENTS
router.get(
  "/students",
  protect,
  authorizeRoles("ADMIN"),
  getStudents
);

// GET ALL TEACHERS
router.get(
  "/teachers",
  protect,
  authorizeRoles("ADMIN"),
  getTeachers
);

module.exports = router;