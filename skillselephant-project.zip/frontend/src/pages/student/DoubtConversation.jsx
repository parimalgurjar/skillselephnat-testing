import { useEffect, useState } from "react";
import {
  ArrowLeft,
  Send,
  MessageSquare,
  User,
  Clock3,
  CheckCircle2,
 
} from "lucide-react";
import {
  useNavigate,
  useParams,
} from "react-router-dom";
import DoubtChatComposer from "../../components/doubts/DoubtChatComposer";
import {
  markConversationNotificationsRead,
} from "../../services/notificationEvents";
import {
  getDoubtById,
  getConversationMessages,
  sendDoubtMessage,
} from "../../services/doubtApi";

import { useAuth } from "../../context/AuthContext";
import AlertModal from "../../components/common/AlertModal";
import "./DoubtConversation.css";

const DoubtConversation = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [alertModal, setAlertModal] = useState({
    isOpen: false,
    type: "error",
    title: "Error",
    message: "",
  });

  const [doubt, setDoubt] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reply, setReply] = useState("");
  const [sending, setSending] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  
const [audioBusy, setAudioBusy] = useState(false);
  const fetchDoubt = async () => {
    try {
      setLoading(true);

      const response = await getDoubtById(id);

      if (response.success) {
        setDoubt(response.doubt);
      }
      const msgResponse = await getConversationMessages(id);

      if (msgResponse.success) {
        setMessages(msgResponse.messages || []);

        void markConversationNotificationsRead(
          `/student/doubts/${id}`,
          msgResponse.notificationReadThrough
        );
      }
    } catch (error) {
      console.error(error);

      setAlertModal({
        isOpen: true,
        type: "error",
        title: "Unable to Load Doubt",
        message: error.message || "Unable to fetch doubt details",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoubt();
  }, [id]);
  useEffect(() => {
  if (!id || loading) return;

  let active = true;
  let refreshing = false;

  const conversationLink = window.location.pathname;

  const refreshConversation = async () => {
    if (
      !active ||
      refreshing ||
      document.visibilityState !== "visible"
    ) {
      return;
    }

    refreshing = true;

    try {
      const [doubtResponse, messageResponse] =
        await Promise.all([
          getDoubtById(id),
          getConversationMessages(id),
        ]);

      if (!active) return;

      if (doubtResponse?.success) {
        setDoubt(doubtResponse.doubt);
      }

      if (messageResponse?.success) {
        setMessages(messageResponse.messages || []);

        void markConversationNotificationsRead(
          conversationLink,
          messageResponse.notificationReadThrough
        );
      }
    } catch (error) {
      if (active) {
        console.error(
          "Chat background refresh failed:",
          error.message
        );
      }
    } finally {
      refreshing = false;
    }
  };

  const timer = window.setInterval(
    refreshConversation,
    5000
  );

  window.addEventListener("focus", refreshConversation);
  window.addEventListener("online", refreshConversation);
  document.addEventListener(
    "visibilitychange",
    refreshConversation
  );

  return () => {
    active = false;
    window.clearInterval(timer);

    window.removeEventListener(
      "focus",
      refreshConversation
    );

    window.removeEventListener(
      "online",
      refreshConversation
    );

    document.removeEventListener(
      "visibilitychange",
      refreshConversation
    );
  };
}, [id, loading]);

  const handleSendReply = async (e) => {
    e.preventDefault();
    if (sending || audioBusy) return;

    if (!reply.trim() && !selectedFile) {
      return;
    }

    try {
      setSending(true);

      const response = await sendDoubtMessage(id, {
        message: reply,
        file: selectedFile,
      });

      if (response.success) {
        setReply("");
        setSelectedFile(null);
        

        await fetchDoubt();
      }
    } catch (error) {
      console.error(error);

      setAlertModal({
        isOpen: true,
        type: "error",
        title: "Reply Failed",
        message: error.message || "Unable to send reply",
      });
    } finally {
      setSending(false);
    }
  };

  const getStatusClass = (status) => {
    switch (status) {
      case "RESOLVED":
        return "resolved";

      case "IN_PROGRESS":
        return "progress";

      default:
        return "pending";
    }
  };

  if (loading) {
    return (
      <div className="conversation-loading">
        Loading conversation...
      </div>
    );
  }

  if (!doubt) {
    return (
      <div className="conversation-loading">
        Doubt not found
      </div>
    );
  }

  return (
    <div className="doubt-conversation-page">

      {/* ================= BACK BUTTON ================= */}

      <button
        type="button"
        className="conversation-back-button"
        onClick={() =>
          navigate("/student/doubts")
        }
      >
        <ArrowLeft size={18} />
        Back to My Doubts
      </button>

      {/* ================= DOUBT HEADER ================= */}

      <div className="conversation-header-card">
        <div className="conversation-header-top">

          <div>
            <div className="conversation-topic">
              {doubt.topic}
            </div>

            <h1>{doubt.title}</h1>
          </div>

          <div
            className={`conversation-status ${getStatusClass(
              doubt.status
            )}`}
          >
            {doubt.status === "RESOLVED" ? (
              <CheckCircle2 size={16} />
            ) : (
              <Clock3 size={16} />
            )}

            {doubt.status.replace("_", " ")}
          </div>
        </div>

        <p className="conversation-description">
          {doubt.description}
        </p>

        <div className="conversation-meta">

          <div className="conversation-teacher">
            <User size={16} />

            <span>
              Assigned Teacher:
              <strong>
                {" "}
                {doubt.assignedTeacher?.name ||
                  "Not assigned"}
              </strong>
            </span>
          </div>

          <span>
            {new Date(
              doubt.createdAt
            ).toLocaleString()}
          </span>
        </div>
      </div>

      {/* ================= CHAT ================= */}

      <div className="conversation-chat">

        <div className="conversation-chat-header">
          <MessageSquare size={19} />

          <div>
            <h3>Discussion</h3>

            <span>
              Communicate with your assigned teacher
            </span>
          </div>
        </div>

        <div className="conversation-messages">

          {/* ORIGINAL DOUBT MESSAGE */}

          <div className="conversation-message se-chat-outgoing">
            <div className="message-avatar">
              {doubt.studentId?.name
                ?.charAt(0)
                ?.toUpperCase() || "S"}
            </div>

            <div className="message-content">
              <div className="message-user">
                {doubt.studentId?.name || "Student"}

                <span>Student</span>
              </div>

              <div className="message-bubble">
                {doubt.description}
              </div>

              <small>
                {new Date(
                  doubt.createdAt
                ).toLocaleString()}
              </small>
            </div>
          </div>

          {/* REPLIES / MESSAGES */}

          {(messages.length > 0 ? messages : doubt.replies || [])?.map((item) => {
            const currentUserId = user?._id || user?.id;

const senderId =
  typeof item.senderId === "object"
    ? item.senderId?._id || item.senderId?.id
    : item.senderId;

const messageRole =
  item.senderRole || item.senderId?.role;

const isCurrentUser =
  senderId && currentUserId
    ? String(senderId) === String(currentUserId)
    : messageRole === "STUDENT";

            const senderName =
              item.senderId?.name ||
              (isCurrentUser
                ? user?.name || "You"
                : "User");

            const senderRole =
              item.senderId?.role ||
              "";

            return (
              <div
                key={item._id}
               className={`conversation-message ${
  isCurrentUser
    ? "se-chat-outgoing"
    : "se-chat-incoming"
}`}
              >
                <div className="message-avatar">
                  {senderName
                    .charAt(0)
                    .toUpperCase()}
                </div>

                <div className="message-content">
                  <div className="message-user">
                    {isCurrentUser
                      ? "You"
                      : senderName}

                    <span>
                      {senderRole === "STUDENT"
                        ? "Student"
                        : senderRole === "TEACHER"
                        ? "Teacher"
                        : senderRole}
                    </span>
                  </div>

                  <div className="message-bubble">
                    {item.message}
{item.legacyAttachments?.length > 0 && (
  <div className="message-attachment">
    {item.legacyAttachments.map((url, index) => (
      <a
        key={`${item._id}-attachment-${index}`}
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="attachment-file"
      >
        📎 Open attachment {index + 1}
      </a>
    ))}
  </div>
)}
                    {item.attachment?.url && (
                      <div className="message-attachment">
                        {item.attachment.type === "image" && (
                          <img
                            src={item.attachment.url}
                            alt={item.attachment.filename || "Attachment"}
                            className="attachment-image"
                          />
                        )}

                        {item.attachment.type === "video" && (
                          <video
                            src={item.attachment.url}
                            controls
                            className="attachment-video"
                          />
                        )}
                        {item.attachment.type === "audio" && (
  <div className="attachment-audio">
    <audio
      src={item.attachment.url}
      controls
      preload="metadata"
    >
      Your browser does not support audio playback.
    </audio>

    <small>
      {item.attachment.filename || "Voice message"}
    </small>
  </div>
)}

                        {item.attachment.type === "file" && (
                          <a
                            href={item.attachment.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="attachment-file"
                          >
                            📎 {item.attachment.filename || "Open file"}
                          </a>
                        )}
                      </div>
                    )}
                  </div>

                  <small>
                    {item.createdAt
                      ? new Date(
                          item.createdAt
                        ).toLocaleString("en-IN")
                      : ""}
                  </small>
                </div>
              </div>
            );
          })}
        </div>

        {/* ================= REPLY BOX ================= */}

    {doubt.status !== "RESOLVED" && (
  <DoubtChatComposer
    key={id}
    value={reply}
    onChange={setReply}
    file={selectedFile}
    onFileChange={setSelectedFile}
    sending={sending}
    onBusyChange={setAudioBusy}
    onSubmit={handleSendReply}
  />
)}

        {doubt.status === "RESOLVED" && (
          <div className="conversation-resolved-message">
            <CheckCircle2 size={20} />

            This doubt has been marked as resolved.
          </div>
        )}
      </div>

      <AlertModal
        isOpen={alertModal.isOpen}
        type={alertModal.type}
        title={alertModal.title}
        message={alertModal.message}
        onClose={() =>
          setAlertModal((prev) => ({
            ...prev,
            isOpen: false,
          }))
        }
      />
    </div>
  );
};

export default DoubtConversation;