
import { useCallback, useEffect, useState } from "react";
import { IndianRupee, RefreshCw, Search, Wallet } from "lucide-react";
import api from "../../services/api";
import "./TeacherFees.css";

const money = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Number(amount || 0));

const dateLabel = (date) =>
  date
    ? new Date(date).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })
    : "Not configured";

const TeacherFees = () => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [savingId, setSavingId] = useState("");

  const loadFees = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const response = await api.get("/fees/students");
      setStudents(response.data?.students || []);
    } catch (err) {
      setError(
        err.response?.data?.message ||
          "Fees load nahi hui. Permission aur backend check karein."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadFees();
  }, [loadFees]);

  const setFee = async (record) => {
    const student = record.student;
    if (!student?._id) return;

    const input = window.prompt(
      `${student.name} ki total fee enter karein (₹):`,
      record.configured ? String(record.totalFee) : ""
    );

    if (input === null) return;

    const totalFee = Number(input);

    if (!Number.isFinite(totalFee) || totalFee <= 0) {
      window.alert("Valid fee amount enter karein.");
      return;
    }

    try {
      setSavingId(student._id);

      await api.put(`/fees/students/${student._id}`, {
        totalFee,
      });

      await loadFees();
      window.alert("Student ki fee save ho gayi.");
    } catch (err) {
      window.alert(
        err.response?.data?.message || "Fee save nahi ho payi."
      );
    } finally {
      setSavingId("");
    }
  };

  const addInstallment = async (record) => {
    const student = record.student;
    if (!student?._id || !record.configured) {
      window.alert("Pehle student ki total fee set karein.");
      return;
    }

    if (record.balanceAmount <= 0) {
      window.alert("Student ki fee already complete hai.");
      return;
    }

    const input = window.prompt(
      `${student.name} ki payment amount enter karein (₹):`,
      String(record.balanceAmount)
    );

    if (input === null) return;

    const amount = Number(input);

    if (!Number.isFinite(amount) || amount <= 0) {
      window.alert("Valid installment amount enter karein.");
      return;
    }

    const note = window.prompt("Payment note (optional):", "") ?? "";

    try {
      setSavingId(student._id);

      await api.post(`/fees/students/${student._id}/installments`, {
        amount,
        note,
      });

      await loadFees();
      window.alert("Installment record ho gayi.");
    } catch (err) {
      window.alert(
        err.response?.data?.message ||
          "Payment record nahi ho payi."
      );
    } finally {
      setSavingId("");
    }
  };

  const query = search.trim().toLowerCase();

  const filteredStudents = students.filter((record) => {
    const student = record.student || {};

    return (
      student.name?.toLowerCase().includes(query) ||
      student.email?.toLowerCase().includes(query) ||
      student.batchTiming?.toLowerCase().includes(query)
    );
  });

  const pendingCount = students.filter(
    (record) => record.configured && record.status === "PENDING"
  ).length;

  const completedCount = students.filter(
    (record) => record.configured && record.status === "COMPLETED"
  ).length;

  return (
    <section className="teacher-fees-page">
      <div className="teacher-fees-heading">
        <div>
          <span className="teacher-fees-eyebrow">EDUCATOR PORTAL</span>
          <h1>Fee Management</h1>
          <p>Apne assigned students ki fees aur installments manage karein.</p>
        </div>

        <button
          type="button"
          className="teacher-fees-refresh"
          onClick={loadFees}
          disabled={loading}
        >
          <RefreshCw size={16} />
          Refresh
        </button>
      </div>

      <div className="teacher-fees-stats">
        <article>
          <span>Assigned Students</span>
          <strong>{students.length}</strong>
        </article>
        <article>
          <span>Pending Fees</span>
          <strong>{pendingCount}</strong>
        </article>
        <article>
          <span>Completed Fees</span>
          <strong>{completedCount}</strong>
        </article>
      </div>

      <div className="teacher-fees-card">
        <div className="teacher-fees-toolbar">
          <div>
            <h2>Student Fee Records</h2>
            <p>Sirf aapke assigned students ke records.</p>
          </div>

          <label className="teacher-fees-search">
            <Search size={17} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search student..."
            />
          </label>
        </div>

        {error && (
          <div className="teacher-fees-error">
            {error}
            <button type="button" onClick={loadFees}>
              Retry
            </button>
          </div>
        )}

        {loading ? (
          <div className="teacher-fees-empty">Loading fee records...</div>
        ) : !error && filteredStudents.length === 0 ? (
          <div className="teacher-fees-empty">
            <Wallet size={28} />
            <p>Koi assigned student fee record nahi mila.</p>
          </div>
        ) : (
          !error && (
            <div className="teacher-fees-table-wrap">
              <table className="teacher-fees-table">
                <thead>
                  <tr>
                    <th>Student</th>
                    <th>Batch</th>
                    <th>Total Fee</th>
                    <th>Paid</th>
                    <th>Balance</th>
                    <th>Deadline</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredStudents.map((record) => {
                    const student = record.student || {};
                    const completed = record.status === "COMPLETED";

                    return (
                      <tr key={student._id}>
                        <td>
                          <strong>{student.name || "Student"}</strong>
                          <small>{student.email || "—"}</small>
                        </td>
                        <td>{student.batchTiming || "Not set"}</td>
                        <td>{record.configured ? money(record.totalFee) : "—"}</td>
                        <td>{record.configured ? money(record.paidAmount) : "—"}</td>
                        <td>{record.configured ? money(record.balanceAmount) : "—"}</td>
                        <td>{dateLabel(record.deadline)}</td>
                        <td>
                          <span
                            className={`teacher-fees-status ${
                              completed ? "completed" : "pending"
                            }`}
                          >
                            {record.configured ? record.status : "Not set"}
                          </span>
                        </td>
                        <td>
                          <div className="teacher-fees-actions">
                            <button
                              type="button"
                              onClick={() => setFee(record)}
                              disabled={savingId === student._id}
                            >
                              {record.configured ? "Edit Fee" : "Set Fee"}
                            </button>

                            <button
                              type="button"
                              className="secondary"
                              onClick={() => addInstallment(record)}
                              disabled={
                                savingId === student._id ||
                                !record.configured ||
                                record.balanceAmount <= 0
                              }
                            >
                              <IndianRupee size={14} />
                              Payment
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )
        )}
      </div>
    </section>
  );
};

export default TeacherFees;
